package com.dynamicpill.module;

import android.content.SharedPreferences;
import android.graphics.drawable.Icon;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;

/** Control Center / Quick Settings tile that flips one boolean preference. */
public abstract class BaseTile extends TileService {
    protected abstract String prefKey();
    protected abstract int iconRes();
    protected abstract String tileName();

    @SuppressWarnings({"deprecation", "WorldReadableFiles"})
    private SharedPreferences prefs() {
        try {
            return getSharedPreferences(PillController.PREF_FILE, MODE_WORLD_READABLE);
        } catch (Throwable t) {
            return getSharedPreferences(PillController.PREF_FILE, MODE_PRIVATE);
        }
    }

    @Override
    public void onStartListening() {
        refresh();
    }

    @Override
    public void onClick() {
        SharedPreferences sp = prefs();
        boolean on = !sp.getBoolean(prefKey(), true);
        sp.edit().putBoolean(prefKey(), on).apply();
        refresh();
    }

    private void refresh() {
        Tile t = getQsTile();
        if (t == null) return;
        boolean on = prefs().getBoolean(prefKey(), true);
        t.setLabel(tileName());
        t.setIcon(Icon.createWithResource(this, iconRes()));
        t.setState(on ? Tile.STATE_ACTIVE : Tile.STATE_INACTIVE);
        t.updateTile();
    }
}
