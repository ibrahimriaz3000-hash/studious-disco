package com.dynamicpill.module;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

/** Black capsule with an indicator dot (right) and an iOS style call speaker icon (left). */
public class PillView extends View {
    private static final int SPEAKER_GREEN = 0xFF34C759;
    /** One full blink (dim and back) takes this long. */
    private static final long BLINK_PERIOD_MS = 1000;
    /** Time for the speaker waves to pulse once (inner wave, then outer wave). */
    private static final long WAVE_PERIOD_MS = 1200;

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint iconFill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint iconWave = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final Path iconPath = new Path();
    private float borderPx = 0f;

    private boolean dotOn = true;
    private int dotColor = 0xFF34C759;
    private boolean speaker = false;
    private float blinkFactor = 1f;
    private ValueAnimator blinkAnim;
    private ValueAnimator waveAnim;
    private float wavePhase = 0f;

    public PillView(Context context) {
        super(context);
        paint.setColor(0xFF000000); // pure dark black, full alpha
        paint.setStyle(Paint.Style.FILL);
        stroke.setColor(0xFFFFFFFF); // border
        stroke.setStyle(Paint.Style.STROKE);
        dot.setStyle(Paint.Style.FILL);
        iconFill.setStyle(Paint.Style.FILL);
        iconFill.setColor(SPEAKER_GREEN);
        iconWave.setStyle(Paint.Style.STROKE);
        iconWave.setStrokeCap(Paint.Cap.ROUND);
        iconWave.setColor(SPEAKER_GREEN);
    }

    /** Border thickness in pixels; 0 = no border. */
    public void setBorder(float px) {
        if (px != borderPx) {
            borderPx = Math.max(0f, px);
            invalidate();
        }
    }

    /** Border colour (white normally, green while charging, yellow during a call). */
    public void setStrokeColor(int color) {
        if (stroke.getColor() != color) {
            stroke.setColor(color);
            invalidate();
        }
    }

    /** 0..100 percent; 100 = fully solid black. */
    public void setPillAlpha(int percent) {
        int a = Math.round(255f * Math.max(0, Math.min(100, percent)) / 100f);
        if (paint.getAlpha() != a) {
            paint.setAlpha(a);
            invalidate();
        }
    }

    /** Indicator dot inside the pill: shown or not, and its colour. */
    public void setDot(boolean on, int color) {
        if (on != dotOn || color != dotColor) {
            dotOn = on;
            dotColor = color;
            invalidate();
        }
    }

    /** Green speaker icon on the left side (incoming / ongoing call). */
    public void setSpeaker(boolean on) {
        if (on != speaker) {
            speaker = on;
            if (on) {
                waveAnim = ValueAnimator.ofFloat(0f, 1f);
                waveAnim.setDuration(WAVE_PERIOD_MS);
                waveAnim.setInterpolator(new android.view.animation.LinearInterpolator());
                waveAnim.setRepeatCount(ValueAnimator.INFINITE);
                waveAnim.addUpdateListener(a -> {
                    wavePhase = (Float) a.getAnimatedValue();
                    invalidate();
                });
                waveAnim.start();
            } else if (waveAnim != null) {
                waveAnim.cancel();
                waveAnim = null;
            }
            invalidate();
        }
    }

    /** Makes the dot fade out and in once per second. */
    public void setBlink(boolean on) {
        if (on) {
            if (blinkAnim != null) return;
            blinkAnim = ValueAnimator.ofFloat(1f, 0.1f);
            blinkAnim.setDuration(BLINK_PERIOD_MS / 2);
            blinkAnim.setRepeatCount(ValueAnimator.INFINITE);
            blinkAnim.setRepeatMode(ValueAnimator.REVERSE);
            blinkAnim.addUpdateListener(a -> {
                blinkFactor = (Float) a.getAnimatedValue();
                invalidate();
            });
            blinkAnim.start();
        } else if (blinkAnim != null) {
            blinkAnim.cancel();
            blinkAnim = null;
            blinkFactor = 1f;
            invalidate();
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (blinkAnim != null) {
            blinkAnim.cancel();
            blinkAnim = null;
            blinkFactor = 1f;
        }
        if (waveAnim != null) {
            waveAnim.cancel();
            waveAnim = null;
            speaker = false;
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth(), h = getHeight();
        rect.set(0, 0, w, h);
        float r = h / 2f;
        canvas.drawRoundRect(rect, r, r, paint);
        if (borderPx > 0f) {
            stroke.setStrokeWidth(borderPx);
            float in = borderPx / 2f;
            rect.set(in, in, w - in, h - in);
            float rr = Math.max(0f, h / 2f - in);
            canvas.drawRoundRect(rect, rr, rr, stroke);
        }

        if (dotOn) {
            dot.setColor(dotColor);
            dot.setAlpha(Math.round(255f * blinkFactor));
            canvas.drawCircle(w - h * 0.5f, h / 2f, h * 0.16f, dot);
        }

        if (speaker) drawSpeaker(canvas, h);
    }

    /** 0.35..1 pulse that travels outwards: delay shifts the wave in time. */
    private float pulse(float delay) {
        double v = 0.5 + 0.5 * Math.cos(2 * Math.PI * (wavePhase - delay));
        return (float) (0.35 + 0.65 * v);
    }

    /** Small speaker with two curvy animated sound waves, centred in the left cap of the pill. */
    private void drawSpeaker(Canvas canvas, float h) {
        float s = h * 0.38f;
        float x0 = h * 0.5f - 0.6f * s;
        float cy = h / 2f;

        iconPath.reset();
        iconPath.moveTo(x0, cy - 0.2f * s);
        iconPath.lineTo(x0 + 0.25f * s, cy - 0.2f * s);
        iconPath.lineTo(x0 + 0.55f * s, cy - 0.5f * s);
        iconPath.lineTo(x0 + 0.55f * s, cy + 0.5f * s);
        iconPath.lineTo(x0 + 0.25f * s, cy + 0.2f * s);
        iconPath.lineTo(x0, cy + 0.2f * s);
        iconPath.close();
        canvas.drawPath(iconPath, iconFill);

        iconWave.setStrokeWidth(Math.max(1.5f, s * 0.15f));
        float cx = x0 + 0.62f * s;
        float r1 = 0.38f * s, r2 = 0.72f * s;
        iconWave.setColor(SPEAKER_GREEN);
        iconWave.setAlpha(Math.round(255f * pulse(0f)));
        rect.set(cx - r1, cy - r1, cx + r1, cy + r1);
        canvas.drawArc(rect, -55f, 110f, false, iconWave);
        iconWave.setAlpha(Math.round(255f * pulse(0.25f)));
        rect.set(cx - r2, cy - r2, cx + r2, cy + r2);
        canvas.drawArc(rect, -55f, 110f, false, iconWave);
    }
}
